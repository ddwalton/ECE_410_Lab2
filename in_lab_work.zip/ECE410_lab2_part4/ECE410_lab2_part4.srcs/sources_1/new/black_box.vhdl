library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity black_box is
    port (
        clock : in STD_LOGIC;
        data_in : in STD_LOGIC;
        clk_en : in STD_LOGIC;
        data : out STD_LOGIC;
        leds : out STD_LOGIC_VECTOR (0 to 2);
        seq_detected : out STD_LOGIC
    );
end black_box;

architecture rtl of black_box is
    signal curr_state : std_logic_vector(2 downto 0) := "000";
    signal next_state : std_logic_vector(2 downto 0) := "001";
    signal slow_clk_en : std_logic := '0'; -- for debouncing clk_en
    signal last_slow_clk_en : std_logic := '0';
begin
    data <= data_in;
    leds <= next_state;
    next_state <= "001" when curr_state = "000" and data_in = '0' else
                  "000" when curr_state = "000" and data_in = '1' else
                  "010" when curr_state = "001" and data_in = '0' else
                  "011" when curr_state = "001" and data_in = '1' else
                  "100" when curr_state = "010" and data_in = '0' else
                  "011" when curr_state = "010" and data_in = '1' else
                  "101" when curr_state = "011" and data_in = '0' else
                  "000" when curr_state = "011" and data_in = '1' else
                  "110" when curr_state = "100" and data_in = '0' else
                  "011" when curr_state = "100" and data_in = '1' else
                  "111" when curr_state = "101" and data_in = '0' else
                  "011" when curr_state = "101" and data_in = '1' else
                  "110" when curr_state = "110" and data_in = '0' else
                  "000" when curr_state = "110" and data_in = '1' else
                  "100" when curr_state = "111" and data_in = '0' else
                  "000" when curr_state = "111" and data_in = '1'; 
                  
    seq_detected <= '1' when next_state = "000" and curr_state /= "000" and curr_state /= "011" else '0';
    
    transition : process(clock)
        variable count : natural := 0;
    begin
        if rising_edge(clock) then
            if (last_slow_clk_en = '1' and slow_clk_en = '0') then
                -- on first seen rising edge of clk_en, transition
                curr_state <= next_state;
                count := 125_000_000 / 10; -- reset count
            else
                if (count > 0) then
                    slow_clk_en <= clk_en;
                    last_slow_clk_en <= slow_clk_en;
                    count := count - 1;
                end if;
            end if;
        end if;
    end process transition;
end rtl;