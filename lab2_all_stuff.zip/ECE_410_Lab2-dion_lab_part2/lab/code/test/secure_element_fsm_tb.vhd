library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

--rgb <=
--        "001" WHEN STARTUP_STATE, -- blue
--        "010" WHEN SECURE_STATE,  -- green
--        "100" WHEN ALARM_STATE,   -- red
--        "110" WHEN IDLE_STATE,    -- yellow
--        "111" WHEN SLEEP_STATE,   -- white
--        "000" WHEN OTHERS;        -- shouldn't be others 

ENTITY secure_element_fsm_tb IS
END ENTITY secure_element_fsm_tb;

ARCHITECTURE test OF secure_element_fsm_tb IS
    SIGNAL clk             : STD_LOGIC := '0';
    SIGNAL rst             : STD_LOGIC := '1';
    SIGNAL busy            : STD_LOGIC := '0';
    SIGNAL self_test       : STD_LOGIC := '0';
    SIGNAL startup         : STD_LOGIC := '0';
    SIGNAL sleep           : STD_LOGIC := '0';
    SIGNAL request         : STD_LOGIC := '0';
    SIGNAL secure_channel  : STD_LOGIC := '0';
    SIGNAL attack_detected : STD_LOGIC := '0';
    SIGNAL rgb             : STD_LOGIC_VECTOR(2 DOWNTO 0);

    CONSTANT clk_period : time := 10 ns;
BEGIN
    uut: ENTITY work.secure_element_fsm PORT MAP (
        clk => clk, 
        rst => rst, 
        busy => busy, 
        self_test => self_test,
        startup => startup, 
        sleep => sleep, 
        request => request,
        secure_channel => secure_channel, 
        attack_detected => attack_detected, 
        rgb => rgb
    );

    gen_clk : PROCESS
    BEGIN
        clk <= '1';
        WAIT FOR clk_period / 2;

        clk <= '0';
        WAIT FOR clk_period / 2;
    END PROCESS gen_clk;

    test_signals : PROCESS
    BEGIN
        rst <= '1';
        startup <= '1';
        
        -- startup
        WAIT FOR clk_period;
        ASSERT (rgb = "001") REPORT "Should be in STARTUP_STATE";

        startup <= '0';
        
        -- go into ALARM_STATE
        rst <= '0';
        self_test <= '0';
        busy <= '0';
        
        WAIT FOR clk_period;
        ASSERT (rgb = "100") REPORT "Should be in ALARM_STATE";


        rst <= '1';
        
        WAIT FOR clk_period;
        ASSERT (rgb = "001") REPORT "Should be in STARTUP_STATE";

        -- go into IDLE_STATE
        rst <= '0';
        self_test <= '1';
        busy <= '0';

        WAIT FOR clk_period;
        ASSERT (rgb = "110") REPORT "Should be in IDLE_STATE";

        -- go into SLEEP_STATE FROM IDLE_STATE
        sleep <= '1';

        WAIT FOR clk_period;
        ASSERT (rgb = "111") REPORT "Should be in SLEEP_STATE";
        
        sleep <= '0';

        -- go into IDLE_STATE again
        request <= '1';

        WAIT FOR clk_period;
        ASSERT (rgb = "101") REPORT "Should be in IDLE_STATE";

        request <= '0';

        -- go into ALARM_STATE from IDLE_STATE
        attack_detected <= '1';

        WAIT FOR clk_period;
        ASSERT (rgb = "100") REPORT "Should be in ALARM_STATE";

        attack_detected <= '0'; -- de-assert attack_detected
        rst <= '1';
        
        WAIT FOR clk_period;
        ASSERT (rgb = "001") REPORT "Should be in STARTUP_STATE";

        -- go into IDLE_STATE
        rst <= '0';
        self_test <= '1';
        busy <= '0';

        WAIT FOR clk_period;
        ASSERT (rgb = "110") REPORT "Should be in IDLE_STATE";

        -- go into SECURE_STATE
        secure_channel <= '1';

        WAIT FOR clk_period;
        ASSERT (rgb = "010") REPORT "Should be in SECURE_STATE";
        
        -- go back to idle
        secure_channel <= '0';
        
        WAIT FOR clk_period;
        ASSERT (rgb = "110") REPORT "Should be in IDLE_STATE";
        
        -- go into secure channel state again
        secure_channel <= '1';
        
        WAIT FOR clk_period;
        ASSERT (rgb = "010") REPORT "Should be in SECURE_STATE";
        
        -- go into sleep from secure
        secure_channel <= '0';
        sleep <= '1';
        
        WAIT FOR clk_period;
        ASSERT (rgb = "111") REPORT "Should be in SLEEP_STATE";
        
        -- leave sleep to idle
        sleep <= '0';
        request <= '1';
        
        WAIT FOR clk_period;
        ASSERT (rgb = "110") REPORT "Should be in IDLE_STATE";
        
        -- go into secure from idle again
        secure_channel <= '1';
        
        WAIT FOR clk_period;
        ASSERT (rgb = "010") REPORT "Should be in SECURE_STATE";
        
        -- go into alarm from secure (final check)
        attack_detected <= '1';
        
        WAIT FOR clk_period;
        ASSERT (rgb = "100") REPORT "Should be in ALARM_STATE";
        
        attack_detected <= '0'; -- should remain in alarm
        
        WAIT FOR clk_period;
        ASSERT (rgb = "100") REPORT "Should be in ALARM_STATE";
        
        -- done
        
        WAIT;
    END PROCESS test_signals;
END ARCHITECTURE test;