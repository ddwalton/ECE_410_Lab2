------------------------------------------------------------------------
-- University  : University of Alberta
-- Course      : ECE 410 Fall 2025
-- Project     : Lab 1
-- Authors     : Antonio Andara Lara
-- Date        : 22-Aug-2025
------------------------------------------------------------------------
-- Description : This is the seven segment display driver. It displays
-- a byte at a time, coupled with the byte_counter it can display 32 bit
-- vectors showing one byte at a time 
------------------------------------------------------------------------

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

ENTITY display_controller IS
	PORT (
		digits : IN STD_LOGIC_VECTOR (7 DOWNTO 0);
		clock  : IN STD_LOGIC;
		display_select : OUT STD_LOGIC := '0';
		segments : OUT STD_LOGIC_VECTOR (6 DOWNTO 0)
	);
END display_controller;

ARCHITECTURE Behavioral OF display_controller IS
	SIGNAL clk_div : STD_LOGIC := '0';
	SIGNAL digit : STD_LOGIC_VECTOR (3 DOWNTO 0);
	SIGNAL count   : INTEGER   := 0;
	CONSTANT limit : INTEGER   := 1_250_000;

BEGIN

	clock_divider : PROCESS (clock)
    BEGIN
        IF rising_edge(clock) THEN
            IF count < limit - 1 THEN
                count <= count + 1;
            ELSE
                count   <= 0;
				clk_div <= not clk_div;
            END IF;
        END IF;
    END PROCESS;

	display_select <= clk_div;

	WITH clk_div SELECT
		digit <= digits(3 DOWNTO 0) WHEN '1',
		         digits(7 DOWNTO 4) WHEN OTHERS;

	WITH digit SELECT -- segments "ABCDEFG" 
		segments <= "1111110" WHEN "0000", --0
					"0000110" WHEN "0001", --1
					"1101101" WHEN "0010", --2
					"1001111" WHEN "0011", --3
					"0010111" WHEN "0100", --4
					"1011011" WHEN "0101", --5
					"1111011" WHEN "0110", --6
					"0001110" WHEN "0111", --7
					"1111111" WHEN "1000", --8
					"1011111" WHEN "1001", --9
					"0111111" WHEN "1010", --A
					"1110011" WHEN "1011", --B
					"1111000" WHEN "1100", --C
					"1100111" WHEN "1101", --D
					"1111001" WHEN "1110", --E
					"0111001" WHEN "1111", --F
					"0000000" WHEN OTHERS;
END Behavioral;