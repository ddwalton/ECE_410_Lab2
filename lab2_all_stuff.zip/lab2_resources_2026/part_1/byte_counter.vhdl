------------------------------------------------------------------------
-- University  : University of Alberta
-- Course      : ECE 410 Fall 2025
-- Project     : Lab 1
-- Authors     : Antonio Andara Lara
-- Date        : 22-Aug-2025
------------------------------------------------------------------------
-- Description : This is this unit reads an input and count from 0 to 3
-- Allowing for the rotation of a 32 bit number displayed on a SSD
------------------------------------------------------------------------

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;
USE IEEE.NUMERIC_STD.ALL;

ENTITY byte_counter IS
    PORT (
        start      : IN STD_LOGIC;
        clock      : IN STD_LOGIC;
        busy       : OUT STD_LOGIC;
        count_led  : OUT STD_LOGIC_VECTOR(1 DOWNTO 0);
        count_byte : OUT STD_LOGIC_VECTOR(1 DOWNTO 0)
    );
END ENTITY;

ARCHITECTURE Behavioral OF byte_counter IS
    SIGNAL clk_out       : STD_LOGIC := '0';
    SIGNAL busy_s        : STD_LOGIC := '0';
    SIGNAL count         : INTEGER   := 0;
    SIGNAL byte_count    : INTEGER   := 0;
    CONSTANT clock_limit : INTEGER   := 125_000_000;
    CONSTANT byte_limit  : INTEGER   := 4;

BEGIN
    divider : PROCESS (clock)
    BEGIN
        IF rising_edge(clock) THEN

            IF start = '1' AND busy_s = '0' THEN
                busy_s <= '1';
                count  <= 0;
            ELSIF busy_s = '1' THEN
                IF count = clock_limit - 1 THEN
                    count <= 0;
                    IF byte_count = byte_limit - 1 THEN
                        byte_count <= 0;
                        busy_s     <= '0';
                    ELSE
                        byte_count <= byte_count + 1;
                    END IF;
                ELSE
                    count <= count + 1;
                END IF;
            END IF;

            clk_out <= NOT clk_out;

        END IF;
    END PROCESS;

    busy       <= busy_s;
    count_led  <= STD_LOGIC_VECTOR(to_unsigned(byte_count, 2));
    count_byte <= STD_LOGIC_VECTOR(to_unsigned(byte_count, 2));
END;
