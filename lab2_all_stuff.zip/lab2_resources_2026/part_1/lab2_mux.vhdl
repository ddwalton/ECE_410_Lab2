------------------------------------------------------------------------
-- University  : University of Alberta
-- Course      : ECE 410 Fall 2025
-- Project     : Lab 1
-- Authors     : Antonio Andara Lara
-- Date        : 22-Aug-2025
------------------------------------------------------------------------
-- Description : Simple 32-bit 4:1 multiplexer
------------------------------------------------------------------------

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY lab1_mux IS
    PORT (
        mux_i : IN STD_LOGIC_VECTOR(31 DOWNTO 0);
        mux_s : IN STD_LOGIC_VECTOR(1 DOWNTO 0);
        mux_o : OUT STD_LOGIC_VECTOR(7 DOWNTO 0)
    );
END ENTITY;

ARCHITECTURE Behavioral OF lab1_mux IS

BEGIN
    WITH mux_s SELECT
        mux_o <= mux_i(31 DOWNTO 24) WHEN "00",
                 mux_i(23 DOWNTO 16) WHEN "01",
                 mux_i(15 DOWNTO 8)  WHEN "10",
                 mux_i(7 DOWNTO 0)   WHEN "11",
                 (OTHERS => '0')     WHEN OTHERS;
END;
