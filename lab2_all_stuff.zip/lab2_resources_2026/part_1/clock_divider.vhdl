------------------------------------------------------------------------
-- University  : University of Alberta
-- Course      : ECE 410 Fall 2025
-- Project     : Lab 2
-- Authors     : Antonio Andara Lara
-- Date        : 22-Sep-2025
------------------------------------------------------------------------
-- Description : In this file we will implement a clock divider, a very useful component
--  and a fundamental block for many projects
-- Additional Comments: Our clock divider will take two generic parameters (the frequencies of the
-- input and output clock signals in Hz) and the output will be the desired output frequency,
-- the divider performs the inner calculation to match the frequencies.
------------------------------------------------------------------------

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY clock_divider IS
    GENERIC (
        freq_in  : INTEGER := 125_000_000; -- input clock frequency in Hz
        freq_out : INTEGER := 1_000        -- output clock frequency in Hz
    );
    PORT (
        clock     : IN STD_LOGIC;
        clock_div : OUT STD_LOGIC
    );
END clock_divider;

ARCHITECTURE Behavioral OF clock_divider IS
    CONSTANT limit      : INTEGER                  := freq_in/(2 * freq_out);
    SIGNAL count        : INTEGER RANGE 1 TO limit := 1; -- set the counter range
    SIGNAL clock_signal : STD_LOGIC                := '0';

BEGIN
    clock_div <= clock_signal;

    PROCESS (clock)
    BEGIN
        IF rising_edge(clock) THEN
            IF count < limit - 1 THEN
                count <= count + 1;
            ELSE
                count        <= 1;
                clock_signal <= NOT clock_signal;
            END IF;
        END IF;
    END PROCESS;

END Behavioral;
