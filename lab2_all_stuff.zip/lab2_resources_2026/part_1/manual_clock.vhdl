------------------------------------------------------------------------
-- University  : University of Alberta
-- Course      : ECE 410 Fall 2025
-- Project     : Lab 2
-- Authors     : Antonio Andara Lara
-- Date        : 22-Sep-2025
------------------------------------------------------------------------
-- Description : Design to manually step through clock cycles using a 20 Hz clock divider to prevent bounce
------------------------------------------------------------------------

LIBRARY IEEE;
USE IEEE.STD_LOGIC_1164.ALL;

ENTITY manual_clock IS
    PORT (
        clock   : IN STD_LOGIC;
        btn     : IN STD_LOGIC;
        clk_out : OUT STD_LOGIC
    );
END manual_clock;

ARCHITECTURE Behavioral OF manual_clock IS
    SIGNAL clock_div : STD_LOGIC := '0';
BEGIN
    clk_div : ENTITY work.clock_divider(Behavioral) GENERIC MAP(freq_out => 20) PORT MAP(clock => clock, clock_div => clock_div);
    PROCESS (clock_div)
    BEGIN
        IF rising_edge(clock_div) THEN
            IF btn = '1' THEN
                clk_out <= '1';
            ELSE
                clk_out <= '0';
            END IF;
        END IF;
    END PROCESS;
END Behavioral;
