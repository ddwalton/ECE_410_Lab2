----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date: 10/07/2026 01:58:23 PM
-- Design Name: 
-- Module Name: taus88_generator - Behavioral
-- Project Name: 
-- Target Devices: 
-- Tool Versions: 
-- Description: 
-- 
-- Dependencies: 
-- 
-- Revision:
-- Revision 0.01 - File Created
-- Additional Comments:
-- 
----------------------------------------------------------------------------------


library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
--use IEEE.NUMERIC_STD.ALL;

-- Uncomment the following library declaration if instantiating
-- any Xilinx leaf cells in this code.
--library UNISIM;
--use UNISIM.VComponents.all;

entity taus88_generator is
    Port ( clock : in STD_LOGIC;
           reset : in STD_LOGIC;
           ramdom_output : out STD_LOGIC_VECTOR (31 downto 0));
end taus88_generator;

architecture Behavioral of taus88_generator is

begin


end Behavioral;
